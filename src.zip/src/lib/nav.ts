
export type NavItem = { href: string; label: string }

// ...existing code...

export type UserRole = 'admin' | 'project_manager' | 'technician' | 'viewer';

// ...existing code...

export function getNavByRole(role: UserRole | null): NavItem[] {
  if (role === 'project_manager') {
    return [
      { href: '/dashboard/manager', label: 'Inicio' },
      { href: '/tasks', label: 'Tareas' },
      { href: '/analytics', label: 'Analytics' },
      { href: '/reports', label: 'Reportes' },
    ]
  }
  if (role === 'admin') {
    return [
      { href: '/dashboard/admin', label: 'Inicio' },
      { href: '/tasks', label: 'Tareas' },
      { href: '/reports', label: 'Reportes' },
    ]
  }
  if (role === 'technician') {
    return [
      { href: '/dashboard/technician', label: 'General' },
      { href: '/my-tasks', label: 'Mis tareas' },
    ]
  }
  // viewer u otros
  return [{ href: '/dashboard/view', label: 'Inicio' }]
}
