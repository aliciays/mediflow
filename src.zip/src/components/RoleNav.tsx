// src/components/RoleNav.tsx
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { getNavByRole, UserRole } from '@/lib/nav';
import clsx from 'clsx';

export default function RoleNav({ role }: { role: UserRole }) {
  const pathname = usePathname();
  const items = getNavByRole(role);

  return (
    <nav className="hidden md:flex items-center gap-4">
      {items.map(({ label, href }) => {
        const active = pathname?.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            className={clsx(
              'rounded-xl px-3 py-2 text-sm transition-colors',
              active
                ? 'bg-gray-900 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            )}
          >
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
