'use client'

import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { getNavByRole } from '@/lib/nav'
import { useAuth } from '@/context/AuthContext'
import { useEffect, useRef, useState } from 'react'
import clsx from 'clsx'

export default function Header() {
  const { user, role, loading, logout } = useAuth()
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  // cerrar menú al click fuera
  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [])

  const nav = getNavByRole(role ?? null)

  // Nombre y avatar (puedes mapear por uid o por role)
  const displayName =
    user?.displayName ??
    (role === 'project_manager' ? 'Laura García' :
     role === 'technician' ? 'Miguel Técnico' :
     role === 'admin' ? 'Admin General' : 'Usuario')

  const avatarSrc =
    role === 'project_manager'
      ? '/avatars/laura.jpg'
      : role === 'technician'
      ? '/avatars/miguel.jpg'
      : role === 'admin'
      ? '/avatars/admin.jpg'
      : '/avatars/default.jpg'

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/70 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
        {/* Logo + título */}
        <Link href="/" className="flex items-center gap-2">
          <Image src="/mediflow-logo.svg" alt="MediFlow" width={28} height={28} />
          <span className="text-sm font-semibold tracking-wide">MediFlow</span>
        </Link>

        {/* Nav por rol */}
        <nav className="hidden gap-2 md:flex">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                'rounded-md px-3 py-2 text-sm transition',
                pathname?.startsWith(item.href)
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Perfil */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setOpen((v) => !v)}
            className="flex items-center gap-3 rounded-full p-1 hover:bg-gray-100"
            aria-haspopup="menu"
            aria-expanded={open}
          >
            <div className="text-right hidden sm:block">
              <div className="text-sm font-medium leading-4">{displayName}</div>
              <div className="text-[11px] text-gray-500">{loading ? 'Cargando…' : role ?? '—'}</div>
            </div>
            <Image
              src={avatarSrc}
              alt={displayName}
              width={36}
              height={36}
              className="rounded-full ring-1 ring-gray-200"
            />
          </button>

          {/* Dropdown */}
          {open && (
            <div
              role="menu"
              className="absolute right-0 mt-2 w-44 overflow-hidden rounded-xl border bg-white shadow-lg"
            >
              <Link
                href="/settings"
                onClick={() => setOpen(false)}
                className="block px-3 py-2 text-sm hover:bg-gray-50"
              >
                Settings
              </Link>
              <button
                className="block w-full px-3 py-2 text-left text-sm hover:bg-gray-50"
                onClick={logout}
              >
                Cerrar sesión
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Nav compacto en móvil */}
      <div className="border-t bg-white md:hidden">
        <div className="mx-auto flex max-w-7xl overflow-x-auto px-2 py-2">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                'whitespace-nowrap rounded-md px-3 py-1.5 text-sm',
                pathname?.startsWith(item.href)
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              )}
            >
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </header>
  )
}
