export default function ReportsPage() {
  return <div className="text-sm text-slate-700">Placeholder de Reportes.</div>;
}
