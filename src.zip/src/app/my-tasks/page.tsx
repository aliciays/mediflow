export default function MyTasksPage() {
  return <div className="text-sm text-slate-700">Aquí listaremos MIS tareas (según usuario autenticado).</div>;
}
