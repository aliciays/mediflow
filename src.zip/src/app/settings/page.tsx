export default function SettingsPage() {
  return <div className="text-sm text-slate-700">Ajustes de perfil (placeholder).</div>;
}
