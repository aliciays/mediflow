export default function TasksAllPage() {
  return <div className="text-sm text-slate-700">Aquí listaremos TODAS las tareas (solo PM).</div>;
}
