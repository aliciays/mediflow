export default function AnalyticsPage() {
  return <div className="text-sm text-slate-700">Placeholder de Analytics (PM).</div>;
}
