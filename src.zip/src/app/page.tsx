'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useUser } from '@/lib/useUser';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function WelcomePage() {
  const { user, loading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (user) {
      // Si ya está logueado, mandarlo a su dashboard
      const target =
        user.role === 'admin'            ? '/dashboard/admin' :
        user.role === 'project_manager'  ? '/dashboard/pm' :
        user.role === 'technician'       ? '/dashboard/tech' :
                                           '/dashboard/viewer';
      router.replace(target);
    }
  }, [loading, user, router]);

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      {/* Logo */}
      <div className="mb-6">
        <Image
          src="/mediflow-logo.svg"
          alt="MediFlow"
          width={64}
          height={64}
          priority
        />
      </div>

      {/* Título y subtítulo */}
      <h1 className="text-3xl font-bold mb-2">Bienvenido a MediFlow</h1>
      <p className="text-gray-600 mb-8 text-center max-w-md">
        Plataforma especializada para la gestión de proyectos técnicos en dispositivos médicos.
      </p>

      {/* Botones */}
      <div className="flex gap-4">
        <Link
          href="/login"
          className="px-6 py-3 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
        >
          Iniciar sesión
        </Link>
        <Link
          href="/register"
          className="px-6 py-3 rounded-lg border border-gray-300 hover:bg-gray-100 transition"
        >
          Registrarse
        </Link>
      </div>
    </main>
  );
}
