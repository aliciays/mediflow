'use client';
import RequireRole from '@/components/auth/RequireRole';
import { db } from '@/lib/firebase';
import { collection, getDocs, Timestamp } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

type Project = {
  id: string;
  name: string;
  progress: number;
  phase: string;
};

export default function AdminDashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasksThisWeek, setTasksThisWeek] = useState(0);
  const [criticalAlerts, setCriticalAlerts] = useState(0);
  const router = useRouter();

  useEffect(() => {
    const fetchData = async () => {
      const projSnap = await getDocs(collection(db, 'projects'));

      const projList: Project[] = [];
      let totalTasksThisWeek = 0;
      let totalCritical = 0;

      const now = new Date();
      const weekAhead = new Date();
      weekAhead.setDate(now.getDate() + 7);

      for (const docSnap of projSnap.docs) {
        let phaseName = 'Sin fase asignada';
        let completedTasks = 0;
        let totalTasksProject = 0;

        const phasesSnap = await getDocs(collection(db, `projects/${docSnap.id}/phases`));
        if (!phasesSnap.empty) {
          const active = phasesSnap.docs.find(p => p.data().status === 'in_progress');
          phaseName = (active ? active.data().name : phasesSnap.docs[0].data().name) as string;

          for (const phaseDoc of phasesSnap.docs) {
            const tasksSnap = await getDocs(collection(db, `projects/${docSnap.id}/phases/${phaseDoc.id}/tasks`));
            tasksSnap.forEach(taskDoc => {
              const t = taskDoc.data();
              totalTasksProject++;
              if (t.status === 'completed') completedTasks += 1;
              else if (t.status === 'in_progress') completedTasks += 0.5;

              if (t.dueDate instanceof Timestamp) {
                const due = t.dueDate.toDate();
                if (due >= now && due <= weekAhead) totalTasksThisWeek++;
                if (t.priority === 'high' && due < now && t.status !== 'completed') totalCritical++;
              }
            });
          }
        }

        const progress =
          totalTasksProject > 0 ? Math.round((completedTasks / totalTasksProject) * 100) : 0;

        projList.push({
          id: docSnap.id,
          name: (docSnap.data() as any).name,
          phase: phaseName,
          progress
        });
      }

      setProjects(projList);
      setTasksThisWeek(totalTasksThisWeek);
      setCriticalAlerts(totalCritical);
    };

    fetchData();
  }, []);

  return (
    <RequireRole allowed={['admin']}>
      <div className="p-6 space-y-8">
        {/* RESUMEN */}
        <h1 className="text-2xl font-bold mb-4">Resumen</h1>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 bg-white shadow rounded text-center">
            <div className="text-3xl font-bold">{projects.length}</div>
            <div className="text-xs opacity-70">Proyectos activos</div>
          </div>
          <div className="p-4 bg-white shadow rounded text-center">
            <div className="text-3xl font-bold">{tasksThisWeek}</div>
            <div className="text-xs opacity-70">Tareas próximas (7 días)</div>
          </div>
          <div className="p-4 bg-white shadow rounded text-center">
            <div className="text-3xl font-bold text-red-600">{criticalAlerts}</div>
            <div className="text-xs opacity-70">Alertas críticas</div>
          </div>
        </div>

        {/* LISTA DE PROYECTOS */}
        <h2 className="text-xl font-semibold">Proyectos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {projects.map((p) => (
            <div key={p.id} className="p-4 bg-white shadow rounded">
              <div className="flex justify-between">
                <h3 className="font-semibold">{p.name}</h3>
                <span>{p.progress}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded mt-1 mb-3">
                <div className="h-2 bg-blue-500 rounded" style={{ width: `${p.progress}%` }} />
              </div>
              <div className="flex justify-between text-sm">
                <span>Fase: {p.phase}</span>
              </div>
              <div className="flex justify-end mt-2">
                <button
                  className="px-3 py-1 bg-blue-500 text-white rounded"
                  onClick={() => router.push(`/dashboard/projects/${p.id}`)}
                >
                  Ver detalle
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* BOTONES (solo reportes para Admin) */}
        <div className="flex gap-4 mt-6">
          <button className="flex-1 p-2 bg-yellow-500 text-white rounded">
            Generar reporte
          </button>
        </div>
      </div>
    </RequireRole>
  );
}
